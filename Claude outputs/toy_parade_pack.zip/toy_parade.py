"""Small Party World 리듬게임용 12인 합주곡 #1 '장난감 행진' (Toy Parade)
- 116 BPM, 4/4, C장조, 32마디 (약 66초)
- 파트 12개 = 플레이어 12명. 각 파트의 음표 목록이 곧 리듬게임 채보(chart)가 된다
- 모든 소리는 코드로 합성 (샘플·외부 음원 없음)
출력: out/toy_parade_mix.(wav|ogg|mp3), out/stems/NN_part.ogg, out/toy_parade_chart.json
"""
import json, os
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt

SR = 44100
BPM = 116
BEAT = 60.0 / BPM
BAR = 4 * BEAT
BARS = 32
rng = np.random.default_rng(7)

NOTE = {'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11}
def m(n):  # 'C5' -> midi
    return 12 * (int(n[-1]) + 1) + NOTE[n[0]] + (1 if '#' in n else 0)
def hz(midi):
    return 440.0 * 2 ** ((midi - 69) / 12)

# ---------- 곡 구조 ----------
# 마디별 코드 (근음, 구성음)
CH = {'C': ['C', 'E', 'G'], 'Am': ['A', 'C', 'E'], 'F': ['F', 'A', 'C'], 'G': ['G', 'B', 'D'],
      'Em': ['E', 'G', 'B'], 'Dm': ['D', 'F', 'A']}
A_PROG = ['C', 'Am', 'F', 'G', 'C', 'Am', 'F|G', 'C']
B_PROG = ['F', 'G', 'Em', 'Am', 'F', 'G', 'C', 'C']
SECTIONS = [('intro', ['C', 'Am', 'F', 'G']), ('A', A_PROG), ('B', B_PROG), ('A2', A_PROG), ('outro', ['F', 'G', 'C', 'C'])]
bars = []  # (section, chord_at(beat_in_bar))
for name, prog in SECTIONS:
    for c in prog:
        bars.append((name, c))
assert len(bars) == BARS

def chord_at(bar, beat):
    c = bars[bar][1]
    if '|' in c:
        a, b = c.split('|')
        return a if beat < 2 else b
    return c

def sec_start(name):
    return next(i for i, b in enumerate(bars) if b[0] == name)

# ---------- 멜로디 (마디 안 박, 음, 길이) ----------
MEL_A = [
    [(0, 'E5', .5), (.5, 'G5', .5), (1, 'C6', 1), (2, 'B5', .5), (2.5, 'A5', .5), (3, 'G5', 1)],
    [(0, 'A5', .5), (.5, 'G5', .5), (1, 'E5', 1), (2, 'C5', 1), (3, 'E5', 1)],
    [(0, 'F5', .5), (.5, 'A5', .5), (1, 'C6', 1.5), (2.5, 'A5', .5), (3, 'F5', 1)],
    [(0, 'G5', 1), (1, 'B5', .5), (1.5, 'A5', .5), (2, 'G5', 2)],
    [(0, 'E5', .5), (.5, 'G5', .5), (1, 'C6', 1), (2, 'B5', .5), (2.5, 'A5', .5), (3, 'G5', 1)],
    [(0, 'A5', .5), (.5, 'C6', .5), (1, 'E6', 1), (2, 'D6', .5), (2.5, 'C6', .5), (3, 'A5', 1)],
    [(0, 'F5', .5), (.5, 'A5', .5), (1, 'C6', .5), (1.5, 'A5', .5), (2, 'G5', .5), (2.5, 'B5', .5), (3, 'D6', 1)],
    [(0, 'C6', 3)],
]
MEL_B = [
    [(0, 'A5', 1), (1, 'A5', .5), (1.5, 'C6', .5), (2, 'C6', 1), (3, 'A5', 1)],
    [(0, 'B5', 1), (1, 'B5', .5), (1.5, 'D6', .5), (2, 'D6', 1), (3, 'B5', 1)],
    [(0, 'G5', .5), (.5, 'B5', .5), (1, 'E6', 1), (2, 'D6', .5), (2.5, 'B5', .5), (3, 'G5', 1)],
    [(0, 'A5', 1.5), (1.5, 'C6', .5), (2, 'E6', 2)],
    [(0, 'F6', 1), (1, 'E6', .5), (1.5, 'D6', .5), (2, 'C6', 1), (3, 'A5', 1)],
    [(0, 'D6', 1), (1, 'C6', .5), (1.5, 'B5', .5), (2, 'G5', 2)],
    [(0, 'E5', .5), (.5, 'G5', .5), (1, 'C6', .5), (1.5, 'E6', .5), (2, 'G6', 1), (3, 'E6', 1)],
    [(0, 'C6', 3)],
]
SCALE = [0, 2, 4, 5, 7, 9, 11]
def diatonic_down_third(midi):
    pc, octv = midi % 12, midi // 12
    i = SCALE.index(pc)
    j = i - 2
    return (j % 7 and 0) + SCALE[j % 7] + 12 * (octv + (j // 7))

# ---------- 파트별 음표 생성: 노트 = (시작 박(곡 전체), midi 또는 None, 길이 박, 세기) ----------
parts = {}
def add(part, beat, midi, dur, vel=1.0):
    parts.setdefault(part, []).append((beat, midi, dur, vel))

for bi, (sec, _) in enumerate(bars):
    b0 = bi * 4
    last = bi == BARS - 1
    # 1 킥
    if sec in ('B',):
        for k in range(4): add('kick', b0 + k, None, .5)
    elif sec == 'outro' and bi >= BARS - 2:
        if bi == BARS - 1: add('kick', b0, None, .5)
        else:
            for k in range(4): add('kick', b0 + k, None, .5)
    else:
        add('kick', b0, None, .5); add('kick', b0 + 2, None, .5)
        if sec != 'intro': add('kick', b0 + 2.5, None, .5, .7)
    if last: continue_last = True
    # 2 스네어
    if not last:
        add('snare', b0 + 1, None, .5); add('snare', b0 + 3, None, .5)
        if bi % 8 == 7 and sec != 'intro':
            add('snare', b0 + 3.5, None, .25, .7); add('snare', b0 + 3.75, None, .25, .8)
    # 3 하이햇
    if not last and bi >= 1:
        for k in range(8): add('hat', b0 + k * .5, None, .25, 1.0 if k % 2 == 0 else .6)
    # 4 박수·탬버린
    if sec in ('B', 'A2') and not last:
        add('clap', b0 + 1, None, .5); add('clap', b0 + 3, None, .5)
        if sec == 'B': add('clap', b0 + 3.5, None, .5, .6)
    # 5 베이스
    if not last:
        for k, off in enumerate([0, 1, 2, 3]):
            c = chord_at(bi, off)
            root = m(CH[c][0] + '2')
            if root > m('E2'): root -= 12
            add('bass', b0 + off, root + (12 if k % 2 else 0), .9 if k % 2 == 0 else .45)
    else:
        add('bass', b0, m('C2'), 3)
    # 6 코드 오르간 (뒷박 스탭)
    if not last:
        for off in [.5, 1.5, 2.5, 3.5]:
            c = chord_at(bi, off)
            add('organ', b0 + off, [m(n + '4') for n in CH[c]], .35)
    else:
        add('organ', b0, [m('C4'), m('E4'), m('G4')], 3)
    # 9 아르페지오 (8분음표, 인트로 2마디째부터)
    if (sec != 'intro' or bi >= 2) and not last:
        for k in range(8):
            c = chord_at(bi, k * .5)
            tones = [m(n + '5') for n in CH[c]] + [m(CH[c][0] + '6')]
            add('arp', b0 + k * .5, tones[[0, 1, 2, 3, 2, 1, 2, 1][k]], .35, .8 if k % 2 else 1.0)

# 7 메인 멜로디 / 8 화음 멜로디
for sec, mel in (('A', MEL_A), ('B', MEL_B), ('A2', MEL_A)):
    s0 = sec_start(sec)
    for i, bar in enumerate(mel):
        for (o, n, d) in bar:
            add('lead', (s0 + i) * 4 + o, m(n), d)
            if sec != 'A' or i >= 4:
                add('harmony', (s0 + i) * 4 + o, diatonic_down_third(m(n)), d, .85)
# 인트로 픽업 / 아웃트로 마무리 멜로디
for o, n, d in [(3, 'G5', .5), (3.5, 'B5', .5)]:
    add('lead', 3 * 4 + o, m(n), d)
os0 = sec_start('outro')
for o, n, d in [(0, 'A5', 1), (1, 'C6', 1), (2, 'F6', 2), (4, 'G5', 1), (5, 'B5', 1), (6, 'D6', 2), (8, 'E6', 2), (10, 'D6', 1), (11, 'B5', 1), (12, 'C6', 3)]:
    add('lead', os0 * 4 + o, m(n), d)
    add('harmony', os0 * 4 + o, diatonic_down_third(m(n)), d, .85)

# 10 실로폰 벨 (B, A2: 마디 첫 박·셋째 박 긴 음)
for bi, (sec, _) in enumerate(bars):
    if sec in ('B', 'A2', 'outro') and bi != BARS - 1:
        for off in (0, 2):
            c = chord_at(bi, off)
            add('bell', bi * 4 + off, m(CH[c][1] + '6'), 1.8, .9)
add('bell', (BARS - 1) * 4, m('C7'), 3, 1.0)

# 11 토이 피아노: 각 구간 4·8번째 마디 끝에 대답 소절 + A2 에선 매 마디 3~4박에 추임새
FILLS = [[(2, 'G5'), (2.5, 'A5'), (3, 'B5'), (3.5, 'D6')], [(2, 'E6'), (2.5, 'D6'), (3, 'C6'), (3.5, 'G5')]]
for bi, (sec, _) in enumerate(bars):
    if sec in ('A', 'B', 'A2') and bi % 4 == 3:
        for o, n in FILLS[(bi // 4) % 2]:
            add('toypiano', bi * 4 + o, m(n), .4)
    elif sec == 'A2' and bi % 4 != 3:
        c = chord_at(bi, 3)
        add('toypiano', bi * 4 + 3, m(CH[c][2] + '6'), .4, .8)
        add('toypiano', bi * 4 + 3.5, m(CH[c][1] + '6'), .4, .8)
    elif sec == 'intro' and bi in (0, 2):
        add('toypiano', bi * 4, m('C6'), .4); add('toypiano', bi * 4 + .5, m('E6'), .4); add('toypiano', bi * 4 + 1, m('G6'), .8)

# 12 브라스 히트: 구간 시작·끝 강조
for sec in ('A', 'B', 'A2', 'outro'):
    s0 = sec_start(sec)
    c = chord_at(s0, 0)
    add('brass', s0 * 4, [m(n + '4') for n in CH[c]], .9)
for bi in (sec_start('A') - 1, sec_start('B') - 1, sec_start('A2') - 1):
    add('brass', bi * 4 + 3, [m('G3'), m('B3'), m('D4')], .25, .8)
    add('brass', bi * 4 + 3.5, [m('G3'), m('B3'), m('D4')], .4, .9)
add('brass', (BARS - 1) * 4, [m('C4'), m('E4'), m('G4'), m('C5')], 3, 1.0)
# B·A2 구간: 마디 첫 박 스탭 + 짝수 마디 끝 당김음
for bi, (sec, _) in enumerate(bars):
    if sec in ('B', 'A2') and bi != sec_start(sec):
        c = chord_at(bi, 0)
        add('brass', bi * 4, [m(n + '4') for n in CH[c]], .45, .8)
        if bi % 2 == 1 and bi % 8 != 7:
            c2 = chord_at(bi, 2.5)
            add('brass', bi * 4 + 2.5, [m(n + '4') for n in CH[c2]], .45, .75)

# ---------- 합성 ----------
N = int((BARS * BAR + 2.0) * SR)
def env(n, a=.005, d=.1, s=.6, r=.05, dur=None):
    t = np.arange(n) / SR
    e = np.ones(n) * s
    ai = max(1, int(a * SR)); e[:ai] = np.linspace(0, 1, ai)
    di = int(d * SR); e[ai:ai + di] = np.linspace(1, s, len(e[ai:ai + di]))
    if dur is not None:
        ri = int(dur * SR)
        if ri < n:
            e[ri:] *= np.exp(-(t[ri:] - t[ri]) / max(r, 1e-3))
    return e
def lp(x, f, order=2):
    return sosfilt(butter(order, min(f, SR / 2 - 100), 'low', fs=SR, output='sos'), x)
def hp(x, f, order=2):
    return sosfilt(butter(order, f, 'high', fs=SR, output='sos'), x)
def bp(x, lo, hi):
    return sosfilt(butter(2, [lo, hi], 'band', fs=SR, output='sos'), x)
def tt(sec):
    return np.arange(int(sec * SR)) / SR

def kick(d, v):
    t = tt(.4); f = 45 + 95 * np.exp(-t * 30)
    return v * np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 9) * 1.1
def snare(d, v):
    t = tt(.25); n = bp(rng.standard_normal(len(t)), 1200, 7000) * np.exp(-t * 22)
    return v * (n * .35 + .3 * np.sin(2 * np.pi * 185 * t) * np.exp(-t * 30))
def hat(d, v):
    t = tt(.08); return v * hp(rng.standard_normal(len(t)), 7000) * np.exp(-t * 60) * .16
def clap(d, v):
    t = tt(.3); n = bp(rng.standard_normal(len(t)), 900, 3500)
    e = np.zeros(len(t))
    for k in range(3):
        s = int(k * .011 * SR); e[s:] += np.exp(-(t[:len(t) - s]) * (90 if k < 2 else 18))
    return v * n * e * .4
def bass(midi, d, v):
    t = tt(d * BEAT + .08); f = hz(midi)
    w = np.sign(np.sin(2 * np.pi * f * t)) * .6 + np.sin(2 * np.pi * f * t) * .6
    return v * lp(w, 900) * env(len(t), .004, .08, .7, .04, d * BEAT) * .36
def organ(ms, d, v):
    t = tt(d * BEAT + .06); w = 0
    for mm in ms:
        f = hz(mm); w = w + np.sin(2 * np.pi * f * t) + .5 * np.sin(4 * np.pi * f * t) + .25 * np.sin(6 * np.pi * f * t)
    return v * w / len(ms) * env(len(t), .004, .05, .55, .03, d * BEAT) * .38
def pulse(f, t, duty):
    return np.where((f * t) % 1.0 < duty, 1.0, -1.0)
def lead(midi, d, v):
    t = tt(d * BEAT + .1); f = hz(midi) * (1 + .006 * np.sin(2 * np.pi * 5.5 * t) * np.clip(t * 3 - .4, 0, 1))
    ph = np.cumsum(f) / SR
    w = np.where(ph % 1.0 < .25, 1.0, -1.0)
    return v * lp(w, 5200) * env(len(t), .006, .1, .65, .06, d * BEAT - .02) * .26
def harmony(midi, d, v):
    t = tt(d * BEAT + .1); f = hz(midi)
    w = 2 * np.abs(2 * ((f * t) % 1.0) - 1) - 1
    return v * w * env(len(t), .01, .1, .7, .07, d * BEAT - .02) * .3
def arp(midi, d, v):
    t = tt(.22); f = hz(midi)
    return v * lp(pulse(f, t, .125), 4000) * np.exp(-t * 16) * .2
def bell(midi, d, v):
    t = tt(d * BEAT + .6); f = hz(midi)
    mod = 2.2 * np.exp(-t * 4) * np.sin(2 * np.pi * f * 3.5 * t)
    return v * np.sin(2 * np.pi * f * t + mod) * np.exp(-t * 2.6) * .24
def toypiano(midi, d, v):
    t = tt(.6); f = hz(midi) * 1.002
    w = np.sin(2 * np.pi * f * t) + .35 * np.sin(2 * np.pi * f * 2.01 * t) * np.exp(-t * 8) + .2 * np.sin(2 * np.pi * f * 4.2 * t) * np.exp(-t * 20)
    return v * w * np.exp(-t * 7) * .3
def brass(ms, d, v):
    t = tt(d * BEAT + .12); w = 0
    for mm in ms:
        f = hz(mm)
        for det in (-.004, .004):
            w = w + 2 * ((f * (1 + det) * t) % 1.0) - 1
    cut = 600 + 2600 * np.clip(t * 12, 0, 1) * np.exp(-t * 2)
    y = lp(w / (2 * len(ms)), 3000) * (.6 + .4 * np.clip(cut / 3200, 0, 1))
    return v * y * env(len(t), .02, .1, .75, .06, d * BEAT) * .85

PARTS = [  # (키, 이름, 합성 함수, 음높이 있음, 팬(-1~1), 레인 수)
    ('kick', '킥 드럼', kick, False, 0.0),
    ('snare', '스네어', snare, False, -0.1),
    ('hat', '하이햇', hat, False, 0.35),
    ('clap', '박수', clap, False, -0.35),
    ('bass', '베이스', bass, True, 0.0),
    ('organ', '코드 오르간', organ, True, -0.45),
    ('lead', '메인 멜로디', lead, True, 0.05),
    ('harmony', '화음 멜로디', harmony, True, 0.3),
    ('arp', '아르페지오', arp, True, 0.55),
    ('bell', '실로폰', bell, True, -0.6),
    ('toypiano', '토이 피아노', toypiano, True, 0.6),
    ('brass', '브라스 히트', brass, True, -0.2),
]
os.makedirs('out/stems', exist_ok=True)
mix = np.zeros((N, 2))
chart = {'title': '장난감 행진 (Toy Parade)', 'bpm': BPM, 'beats_per_bar': 4, 'bars': BARS,
         'duration': round(BARS * BAR, 3), 'offset': 0.0, 'parts': []}
for idx, (key, name, fn, pitched, pan) in enumerate(PARTS):
    track = np.zeros(N)
    notes = sorted(parts.get(key, []), key=lambda x: x[0])
    for (beat, midi, dur, vel) in notes:
        y = fn(midi, dur, vel) if pitched else fn(dur, vel)
        s = int(beat * BEAT * SR)
        e = min(N, s + len(y)); track[s:e] += y[:e - s]
    # 채보: 음높이가 있는 파트는 마디 안 최저~최고음을 4레인으로 나눔 (리듬 파트는 1레인)
    pitches = [n[1] if not isinstance(n[1], list) else max(n[1]) for n in notes if n[1] is not None]
    lo, hi = (min(pitches), max(pitches)) if pitches else (0, 0)
    cn = []
    for (beat, midi, dur, vel) in notes:
        p = None if midi is None else (max(midi) if isinstance(midi, list) else midi)
        lane = 0 if p is None or hi == lo else min(3, int((p - lo) / (hi - lo + 1e-9) * 4))
        cn.append({'beat': round(beat, 3), 'time': round(beat * BEAT, 4), 'lane': lane,
                   'hold': round(dur * BEAT, 3) if dur >= 1.0 else 0.0})
    chart['parts'].append({'slot': idx + 1, 'key': key, 'name': name, 'lanes': 1 if not pitched else 4,
                           'stem': 'stems/%02d_%s.ogg' % (idx + 1, key), 'notes': cn, 'note_count': len(cn)})
    l, r = np.cos((pan + 1) * np.pi / 4), np.sin((pan + 1) * np.pi / 4)
    st = np.stack([track * l, track * r], 1)
    mix += st
    wavfile.write('out/stems/%02d_%s.wav' % (idx + 1, key), SR, (np.clip(st, -1, 1) * 32767 * .9).astype(np.int16))
# 마스터: 살짝 리버브(짧은 딜레이 몇 개) + 리미터
rev = np.zeros_like(mix)
for dl, g in ((.031, .18), (.047, .14), (.071, .1), (.113, .07)):
    k = int(dl * SR); rev[k:] += mix[:-k] * g
mix = mix + lp(rev[:, 0] * 0 + rev[:, 0], 5000)[:, None] * [1, 0] + lp(rev[:, 1], 5000)[:, None] * [0, 1]
peak = np.max(np.abs(mix)); mix = np.tanh(mix / peak * 1.6) / np.tanh(1.6) * .92
wavfile.write('out/toy_parade_mix.wav', SR, (mix * 32767).astype(np.int16))
json.dump(chart, open('out/toy_parade_chart.json', 'w', encoding='utf8'), ensure_ascii=False, indent=1)
print('duration', round(BARS * BAR, 1), 's; notes per part:', {p['key']: p['note_count'] for p in chart['parts']})
